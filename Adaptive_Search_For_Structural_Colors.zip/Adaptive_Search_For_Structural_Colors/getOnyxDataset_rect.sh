rm markComplete
cat /dev/null > ref.dat
mv /Users/emmavargo/inputfile1.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-p-pol.f90
./a.out
mv /Users/emmavargo/inputfile2.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-p-pol.f90
./a.out
mv /Users/emmavargo/inputfile3.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-p-pol.f90
./a.out
mv /Users/emmavargo/inputfile4.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-p-pol.f90
./a.out
mv /Users/emmavargo/inputfile5.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-p-pol.f90
./a.out
mv /Users/emmavargo/inputfile6.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-p-pol.f90
./a.out
mv /Users/emmavargo/inputfile7.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-p-pol.f90
./a.out
mv /Users/emmavargo/inputfile8.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-p-pol.f90
./a.out
mv /Users/emmavargo/inputfile9.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-p-pol.f90
./a.out
mv /Users/emmavargo/inputfile10.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-p-pol.f90
./a.out
mv /Users/emmavargo/inputfile11.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-s-pol.f90
./a.out
mv /Users/emmavargo/inputfile12.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-s-pol.f90
./a.out
mv /Users/emmavargo/inputfile13.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-s-pol.f90
./a.out
mv /Users/emmavargo/inputfile14.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-s-pol.f90
./a.out
mv /Users/emmavargo/inputfile15.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-s-pol.f90
./a.out
mv /Users/emmavargo/inputfile16.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-s-pol.f90
./a.out
mv /Users/emmavargo/inputfile17.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-s-pol.f90
./a.out
mv /Users/emmavargo/inputfile18.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-s-pol.f90
./a.out
mv /Users/emmavargo/inputfile19.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-s-pol.f90
./a.out
mv /Users/emmavargo/inputfile20.dat /Users/emmavargo/inputfile.dat
gfortran /Users/emmavargo/onyx-specified-s-pol.f90
./a.out
touch ~/markComplete